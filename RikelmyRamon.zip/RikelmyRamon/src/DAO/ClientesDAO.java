package DAO;

import beans.Clientes;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ClientesDAO {

    private Connection conn;

    public ClientesDAO() {
        this.conn = Conexao.getConexao();
    }

    public void Salvar(Clientes cliente) throws Exception {
        String sql = "INSERT INTO clientes(nome, email, telefone) VALUES (?, ?, ?)";

        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, cliente.getNome());
            stmt.setString(2, cliente.getEmail());
            stmt.setString(3, cliente.getTelefone());
            stmt.execute();
        } catch (Exception e) {
            throw new Exception("Erro ao salvar: " + e.getMessage());
        }
    }

    public void Atualizar(Clientes cliente) throws Exception {
        String sql = "UPDATE clientes SET nome=?, email=?, telefone=? WHERE id=?";

        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, cliente.getNome());
            stmt.setString(2, cliente.getEmail());
            stmt.setString(3, cliente.getTelefone());
            stmt.execute();
        } catch (Exception e) {
            throw new Exception("Erro ao atualizar: " + e.getMessage());
        }
    }

    public void Excluir(Clientes cliente) throws Exception {
        String sql = "DELETE clientes WHERE id=?";
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.execute();
        } catch (Exception e) {
            throw new Exception("Erro ao atualizar: " + e.getMessage());
        }
    }

    public List<Clientes> getClientes() throws Exception {
        List<Clientes> lista = new ArrayList();
        String sql = "SELECT * FROM clientes";
        
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                Clientes c = new Clientes();
                c.setId_cliente(rs.getInt("id_cliente"));
                c.setNome(rs.getString("nome"));
                c.setEmail(rs.getString("email"));
                c.setTelefone(rs.getString("telefone"));
                
                lista.add(c);
            }
            return lista;
        } catch (Exception e) {
            throw new Exception("Erro ao buscar produtos: " + e.getMessage());
        }
    }
    
    public Clientes GetProduto(int id) throws Exception {
        String sql = "SELECT * FROM clientes WHERE id = ?";
        
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            rs.first();
            Clientes c = new Clientes();
            c.setId_cliente(rs.getInt("id_cliente"));
            c.setNome(rs.getString("nome"));
            c.setEmail(rs.getString("email"));
            c.setTelefone(rs.getString("telefone"));
            return c;
        } catch (Exception e) {
            throw new Exception("Produto não encontrado");
        }
    }
}



