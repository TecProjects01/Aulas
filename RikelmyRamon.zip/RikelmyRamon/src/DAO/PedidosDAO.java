package DAO;

import beans.Pedidos ;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class PedidosDAO {
    private Connection conn;
    
     public PedidosDAO() {
        this.conn = Conexao.getConexao();
    }
     
    public void Salvar(Pedidos pedido) throws Exception{
        try {
            
        } catch (Exception e) {
        }
    }
    
    public void Atualizar(Pedidos pedido) throws Exception{
        try {
            
        } catch (Exception e) {
        }
    }
    
    public void Excluir(Pedidos pedido) throws Exception{
        try {
            
        } catch (Exception e) {
        }
    }
    
    public void Selecionar(Pedidos pedido) throws Exception{
        try {
            
        } catch (Exception e) {
        }
    }
    
    public Pedidos getPedido(int id) throws Exception{
        try {
            
        } catch (Exception e) {
        }
    }
}
