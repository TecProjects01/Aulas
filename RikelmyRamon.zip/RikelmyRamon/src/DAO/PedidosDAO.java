package DAO;

import beans.Pedidos ;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class PedidosDAO {
    private Connection conn;
    
     public PedidosDAO() {
        this.conn = Conexao.getConexao();
    }
     
    public void Salvar(Pedidos pedido) throws Exception {
        String sql = "INSERT INTO clientes(status, valor_total, data) VALUES (?, ?, ?)";

        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, pedido.getStatus());
            stmt.setDouble(2, pedido.getValor_total());
            stmt.setString(3, pedido.getData());
            stmt.execute();
        } catch (Exception e) {
            throw new Exception("Erro ao salvar: " + e.getMessage());
        }
    }

    public void Atualizar(Pedidos pedido) throws Exception {
        String sql = "UPDATE pedidos SET status=?, valor_total=?, data=? WHERE id=?";

        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, pedido.getStatus());
            stmt.setDouble(2, pedido.getValor_total());
            stmt.setString(3, pedido.getData());
            stmt.execute();
        } catch (Exception e) {
            throw new Exception("Erro ao atualizar: " + e.getMessage());
        }
    }

    public void Excluir(Pedidos pedido) throws Exception {
        String sql = "DELETE pedidos WHERE id_pedido=?";
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.execute();
        } catch (Exception e) {
            throw new Exception("Erro ao atualizar: " + e.getMessage());
        }
    }

    public List<Pedidos> getPedidos() throws Exception {
        List<Pedidos> lista = new ArrayList();
        String sql = "SELECT * FROM pedidos";
        
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                Pedidos p = new Pedidos();
                p.setId_pedido(rs.getInt("id_pedido"));
                p.setId_cliente(rs.getInt("id_cliente"));
                p.setStatus(rs.getString("status"));
                p.setValor_total(rs.getDouble("valor_total"));
                p.setData(rs.getString("Data"));
                
                lista.add(p);
            }
            return lista;
        } catch (Exception e) {
            throw new Exception("Erro ao buscar pedidos: " + e.getMessage());
        }
    }
    
    public Pedidos GetPedido(int id_pedido) throws Exception {
        String sql = "SELECT * FROM pedidos WHERE id_pedido = ?";
        
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setInt(1, id_pedido);
            ResultSet rs = stmt.executeQuery();
            rs.first();
            Pedidos p = new Pedidos();
            p.setId_pedido(rs.getInt("id_pedido"));
            p.setId_cliente(rs.getInt("id_cliente"));
            p.setStatus(rs.getString("status"));
            p.setValor_total(rs.getDouble("valor_total"));
            p.setData(rs.getString("data"));
            return p;
        } catch (Exception e) {
            throw new Exception("Pedido não encontrado");
        }
    }
}
