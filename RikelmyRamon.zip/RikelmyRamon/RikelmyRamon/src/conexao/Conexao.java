package conexao;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexao {

    public static Connection getConexao() {
        try {
            
            return DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/RikelmyRamon?serverTimezone=UTC", //URL de conexão
                    "root", //usuario
                    "" //senha
            );
        } catch (Exception e) {
            System.out.println("Erro ao conectar: " + e.getMessage());
            return null;
        }
    }
}
