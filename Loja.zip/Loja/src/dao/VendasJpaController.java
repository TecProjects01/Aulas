/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import beans.Cliente;
import beans.Funcionarios;
import beans.Itens;
import beans.Vendas;
import dao.exceptions.IllegalOrphanException;
import dao.exceptions.NonexistentEntityException;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author IFSP
 */
public class VendasJpaController implements Serializable {

    public VendasJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Vendas vendas) {
        if (vendas.getItensList() == null) {
            vendas.setItensList(new ArrayList<Itens>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Cliente idCliente = vendas.getIdCliente();
            if (idCliente != null) {
                idCliente = em.getReference(idCliente.getClass(), idCliente.getIdCliente());
                vendas.setIdCliente(idCliente);
            }
            Funcionarios idFuncionario = vendas.getIdFuncionario();
            if (idFuncionario != null) {
                idFuncionario = em.getReference(idFuncionario.getClass(), idFuncionario.getIdFuncionario());
                vendas.setIdFuncionario(idFuncionario);
            }
            List<Itens> attachedItensList = new ArrayList<Itens>();
            for (Itens itensListItensToAttach : vendas.getItensList()) {
                itensListItensToAttach = em.getReference(itensListItensToAttach.getClass(), itensListItensToAttach.getIdItem());
                attachedItensList.add(itensListItensToAttach);
            }
            vendas.setItensList(attachedItensList);
            em.persist(vendas);
            if (idCliente != null) {
                idCliente.getVendasList().add(vendas);
                idCliente = em.merge(idCliente);
            }
            if (idFuncionario != null) {
                idFuncionario.getVendasList().add(vendas);
                idFuncionario = em.merge(idFuncionario);
            }
            for (Itens itensListItens : vendas.getItensList()) {
                Vendas oldIdVendaOfItensListItens = itensListItens.getIdVenda();
                itensListItens.setIdVenda(vendas);
                itensListItens = em.merge(itensListItens);
                if (oldIdVendaOfItensListItens != null) {
                    oldIdVendaOfItensListItens.getItensList().remove(itensListItens);
                    oldIdVendaOfItensListItens = em.merge(oldIdVendaOfItensListItens);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Vendas vendas) throws IllegalOrphanException, NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Vendas persistentVendas = em.find(Vendas.class, vendas.getIdVenda());
            Cliente idClienteOld = persistentVendas.getIdCliente();
            Cliente idClienteNew = vendas.getIdCliente();
            Funcionarios idFuncionarioOld = persistentVendas.getIdFuncionario();
            Funcionarios idFuncionarioNew = vendas.getIdFuncionario();
            List<Itens> itensListOld = persistentVendas.getItensList();
            List<Itens> itensListNew = vendas.getItensList();
            List<String> illegalOrphanMessages = null;
            for (Itens itensListOldItens : itensListOld) {
                if (!itensListNew.contains(itensListOldItens)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Itens " + itensListOldItens + " since its idVenda field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            if (idClienteNew != null) {
                idClienteNew = em.getReference(idClienteNew.getClass(), idClienteNew.getIdCliente());
                vendas.setIdCliente(idClienteNew);
            }
            if (idFuncionarioNew != null) {
                idFuncionarioNew = em.getReference(idFuncionarioNew.getClass(), idFuncionarioNew.getIdFuncionario());
                vendas.setIdFuncionario(idFuncionarioNew);
            }
            List<Itens> attachedItensListNew = new ArrayList<Itens>();
            for (Itens itensListNewItensToAttach : itensListNew) {
                itensListNewItensToAttach = em.getReference(itensListNewItensToAttach.getClass(), itensListNewItensToAttach.getIdItem());
                attachedItensListNew.add(itensListNewItensToAttach);
            }
            itensListNew = attachedItensListNew;
            vendas.setItensList(itensListNew);
            vendas = em.merge(vendas);
            if (idClienteOld != null && !idClienteOld.equals(idClienteNew)) {
                idClienteOld.getVendasList().remove(vendas);
                idClienteOld = em.merge(idClienteOld);
            }
            if (idClienteNew != null && !idClienteNew.equals(idClienteOld)) {
                idClienteNew.getVendasList().add(vendas);
                idClienteNew = em.merge(idClienteNew);
            }
            if (idFuncionarioOld != null && !idFuncionarioOld.equals(idFuncionarioNew)) {
                idFuncionarioOld.getVendasList().remove(vendas);
                idFuncionarioOld = em.merge(idFuncionarioOld);
            }
            if (idFuncionarioNew != null && !idFuncionarioNew.equals(idFuncionarioOld)) {
                idFuncionarioNew.getVendasList().add(vendas);
                idFuncionarioNew = em.merge(idFuncionarioNew);
            }
            for (Itens itensListNewItens : itensListNew) {
                if (!itensListOld.contains(itensListNewItens)) {
                    Vendas oldIdVendaOfItensListNewItens = itensListNewItens.getIdVenda();
                    itensListNewItens.setIdVenda(vendas);
                    itensListNewItens = em.merge(itensListNewItens);
                    if (oldIdVendaOfItensListNewItens != null && !oldIdVendaOfItensListNewItens.equals(vendas)) {
                        oldIdVendaOfItensListNewItens.getItensList().remove(itensListNewItens);
                        oldIdVendaOfItensListNewItens = em.merge(oldIdVendaOfItensListNewItens);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = vendas.getIdVenda();
                if (findVendas(id) == null) {
                    throw new NonexistentEntityException("The vendas with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Vendas vendas;
            try {
                vendas = em.getReference(Vendas.class, id);
                vendas.getIdVenda();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The vendas with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            List<Itens> itensListOrphanCheck = vendas.getItensList();
            for (Itens itensListOrphanCheckItens : itensListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Vendas (" + vendas + ") cannot be destroyed since the Itens " + itensListOrphanCheckItens + " in its itensList field has a non-nullable idVenda field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Cliente idCliente = vendas.getIdCliente();
            if (idCliente != null) {
                idCliente.getVendasList().remove(vendas);
                idCliente = em.merge(idCliente);
            }
            Funcionarios idFuncionario = vendas.getIdFuncionario();
            if (idFuncionario != null) {
                idFuncionario.getVendasList().remove(vendas);
                idFuncionario = em.merge(idFuncionario);
            }
            em.remove(vendas);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Vendas> findVendasEntities() {
        return findVendasEntities(true, -1, -1);
    }

    public List<Vendas> findVendasEntities(int maxResults, int firstResult) {
        return findVendasEntities(false, maxResults, firstResult);
    }

    private List<Vendas> findVendasEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Vendas.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Vendas findVendas(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Vendas.class, id);
        } finally {
            em.close();
        }
    }

    public int getVendasCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Vendas> rt = cq.from(Vendas.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
