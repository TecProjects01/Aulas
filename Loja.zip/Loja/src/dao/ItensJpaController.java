/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import beans.Itens;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import beans.Produtos;
import beans.Vendas;
import dao.exceptions.NonexistentEntityException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author IFSP
 */
public class ItensJpaController implements Serializable {

    public ItensJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Itens itens) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Produtos idProduto = itens.getIdProduto();
            if (idProduto != null) {
                idProduto = em.getReference(idProduto.getClass(), idProduto.getIdProduto());
                itens.setIdProduto(idProduto);
            }
            Vendas idVenda = itens.getIdVenda();
            if (idVenda != null) {
                idVenda = em.getReference(idVenda.getClass(), idVenda.getIdVenda());
                itens.setIdVenda(idVenda);
            }
            em.persist(itens);
            if (idProduto != null) {
                idProduto.getItensList().add(itens);
                idProduto = em.merge(idProduto);
            }
            if (idVenda != null) {
                idVenda.getItensList().add(itens);
                idVenda = em.merge(idVenda);
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Itens itens) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Itens persistentItens = em.find(Itens.class, itens.getIdItem());
            Produtos idProdutoOld = persistentItens.getIdProduto();
            Produtos idProdutoNew = itens.getIdProduto();
            Vendas idVendaOld = persistentItens.getIdVenda();
            Vendas idVendaNew = itens.getIdVenda();
            if (idProdutoNew != null) {
                idProdutoNew = em.getReference(idProdutoNew.getClass(), idProdutoNew.getIdProduto());
                itens.setIdProduto(idProdutoNew);
            }
            if (idVendaNew != null) {
                idVendaNew = em.getReference(idVendaNew.getClass(), idVendaNew.getIdVenda());
                itens.setIdVenda(idVendaNew);
            }
            itens = em.merge(itens);
            if (idProdutoOld != null && !idProdutoOld.equals(idProdutoNew)) {
                idProdutoOld.getItensList().remove(itens);
                idProdutoOld = em.merge(idProdutoOld);
            }
            if (idProdutoNew != null && !idProdutoNew.equals(idProdutoOld)) {
                idProdutoNew.getItensList().add(itens);
                idProdutoNew = em.merge(idProdutoNew);
            }
            if (idVendaOld != null && !idVendaOld.equals(idVendaNew)) {
                idVendaOld.getItensList().remove(itens);
                idVendaOld = em.merge(idVendaOld);
            }
            if (idVendaNew != null && !idVendaNew.equals(idVendaOld)) {
                idVendaNew.getItensList().add(itens);
                idVendaNew = em.merge(idVendaNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = itens.getIdItem();
                if (findItens(id) == null) {
                    throw new NonexistentEntityException("The itens with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Itens itens;
            try {
                itens = em.getReference(Itens.class, id);
                itens.getIdItem();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The itens with id " + id + " no longer exists.", enfe);
            }
            Produtos idProduto = itens.getIdProduto();
            if (idProduto != null) {
                idProduto.getItensList().remove(itens);
                idProduto = em.merge(idProduto);
            }
            Vendas idVenda = itens.getIdVenda();
            if (idVenda != null) {
                idVenda.getItensList().remove(itens);
                idVenda = em.merge(idVenda);
            }
            em.remove(itens);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Itens> findItensEntities() {
        return findItensEntities(true, -1, -1);
    }

    public List<Itens> findItensEntities(int maxResults, int firstResult) {
        return findItensEntities(false, maxResults, firstResult);
    }

    private List<Itens> findItensEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Itens.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Itens findItens(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Itens.class, id);
        } finally {
            em.close();
        }
    }

    public int getItensCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Itens> rt = cq.from(Itens.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
