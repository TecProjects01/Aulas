/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import beans.Cliente;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import beans.Vendas;
import dao.exceptions.IllegalOrphanException;
import dao.exceptions.NonexistentEntityException;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author IFSP
 */
public class ClienteJpaController implements Serializable {

    public ClienteJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Cliente cliente) {
        if (cliente.getVendasList() == null) {
            cliente.setVendasList(new ArrayList<Vendas>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            List<Vendas> attachedVendasList = new ArrayList<Vendas>();
            for (Vendas vendasListVendasToAttach : cliente.getVendasList()) {
                vendasListVendasToAttach = em.getReference(vendasListVendasToAttach.getClass(), vendasListVendasToAttach.getIdVenda());
                attachedVendasList.add(vendasListVendasToAttach);
            }
            cliente.setVendasList(attachedVendasList);
            em.persist(cliente);
            for (Vendas vendasListVendas : cliente.getVendasList()) {
                Cliente oldIdClienteOfVendasListVendas = vendasListVendas.getIdCliente();
                vendasListVendas.setIdCliente(cliente);
                vendasListVendas = em.merge(vendasListVendas);
                if (oldIdClienteOfVendasListVendas != null) {
                    oldIdClienteOfVendasListVendas.getVendasList().remove(vendasListVendas);
                    oldIdClienteOfVendasListVendas = em.merge(oldIdClienteOfVendasListVendas);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Cliente cliente) throws IllegalOrphanException, NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Cliente persistentCliente = em.find(Cliente.class, cliente.getIdCliente());
            List<Vendas> vendasListOld = persistentCliente.getVendasList();
            List<Vendas> vendasListNew = cliente.getVendasList();
            List<String> illegalOrphanMessages = null;
            for (Vendas vendasListOldVendas : vendasListOld) {
                if (!vendasListNew.contains(vendasListOldVendas)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Vendas " + vendasListOldVendas + " since its idCliente field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            List<Vendas> attachedVendasListNew = new ArrayList<Vendas>();
            for (Vendas vendasListNewVendasToAttach : vendasListNew) {
                vendasListNewVendasToAttach = em.getReference(vendasListNewVendasToAttach.getClass(), vendasListNewVendasToAttach.getIdVenda());
                attachedVendasListNew.add(vendasListNewVendasToAttach);
            }
            vendasListNew = attachedVendasListNew;
            cliente.setVendasList(vendasListNew);
            cliente = em.merge(cliente);
            for (Vendas vendasListNewVendas : vendasListNew) {
                if (!vendasListOld.contains(vendasListNewVendas)) {
                    Cliente oldIdClienteOfVendasListNewVendas = vendasListNewVendas.getIdCliente();
                    vendasListNewVendas.setIdCliente(cliente);
                    vendasListNewVendas = em.merge(vendasListNewVendas);
                    if (oldIdClienteOfVendasListNewVendas != null && !oldIdClienteOfVendasListNewVendas.equals(cliente)) {
                        oldIdClienteOfVendasListNewVendas.getVendasList().remove(vendasListNewVendas);
                        oldIdClienteOfVendasListNewVendas = em.merge(oldIdClienteOfVendasListNewVendas);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = cliente.getIdCliente();
                if (findCliente(id) == null) {
                    throw new NonexistentEntityException("The cliente with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Cliente cliente;
            try {
                cliente = em.getReference(Cliente.class, id);
                cliente.getIdCliente();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The cliente with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            List<Vendas> vendasListOrphanCheck = cliente.getVendasList();
            for (Vendas vendasListOrphanCheckVendas : vendasListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Cliente (" + cliente + ") cannot be destroyed since the Vendas " + vendasListOrphanCheckVendas + " in its vendasList field has a non-nullable idCliente field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(cliente);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Cliente> findClienteEntities() {
        return findClienteEntities(true, -1, -1);
    }

    public List<Cliente> findClienteEntities(int maxResults, int firstResult) {
        return findClienteEntities(false, maxResults, firstResult);
    }

    private List<Cliente> findClienteEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Cliente.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Cliente findCliente(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Cliente.class, id);
        } finally {
            em.close();
        }
    }

    public int getClienteCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Cliente> rt = cq.from(Cliente.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
