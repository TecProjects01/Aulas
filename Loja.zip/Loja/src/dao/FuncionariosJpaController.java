/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import beans.Funcionarios;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import beans.Vendas;
import dao.exceptions.IllegalOrphanException;
import dao.exceptions.NonexistentEntityException;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author IFSP
 */
public class FuncionariosJpaController implements Serializable {

    public FuncionariosJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Funcionarios funcionarios) {
        if (funcionarios.getVendasList() == null) {
            funcionarios.setVendasList(new ArrayList<Vendas>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            List<Vendas> attachedVendasList = new ArrayList<Vendas>();
            for (Vendas vendasListVendasToAttach : funcionarios.getVendasList()) {
                vendasListVendasToAttach = em.getReference(vendasListVendasToAttach.getClass(), vendasListVendasToAttach.getIdVenda());
                attachedVendasList.add(vendasListVendasToAttach);
            }
            funcionarios.setVendasList(attachedVendasList);
            em.persist(funcionarios);
            for (Vendas vendasListVendas : funcionarios.getVendasList()) {
                Funcionarios oldIdFuncionarioOfVendasListVendas = vendasListVendas.getIdFuncionario();
                vendasListVendas.setIdFuncionario(funcionarios);
                vendasListVendas = em.merge(vendasListVendas);
                if (oldIdFuncionarioOfVendasListVendas != null) {
                    oldIdFuncionarioOfVendasListVendas.getVendasList().remove(vendasListVendas);
                    oldIdFuncionarioOfVendasListVendas = em.merge(oldIdFuncionarioOfVendasListVendas);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Funcionarios funcionarios) throws IllegalOrphanException, NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Funcionarios persistentFuncionarios = em.find(Funcionarios.class, funcionarios.getIdFuncionario());
            List<Vendas> vendasListOld = persistentFuncionarios.getVendasList();
            List<Vendas> vendasListNew = funcionarios.getVendasList();
            List<String> illegalOrphanMessages = null;
            for (Vendas vendasListOldVendas : vendasListOld) {
                if (!vendasListNew.contains(vendasListOldVendas)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Vendas " + vendasListOldVendas + " since its idFuncionario field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            List<Vendas> attachedVendasListNew = new ArrayList<Vendas>();
            for (Vendas vendasListNewVendasToAttach : vendasListNew) {
                vendasListNewVendasToAttach = em.getReference(vendasListNewVendasToAttach.getClass(), vendasListNewVendasToAttach.getIdVenda());
                attachedVendasListNew.add(vendasListNewVendasToAttach);
            }
            vendasListNew = attachedVendasListNew;
            funcionarios.setVendasList(vendasListNew);
            funcionarios = em.merge(funcionarios);
            for (Vendas vendasListNewVendas : vendasListNew) {
                if (!vendasListOld.contains(vendasListNewVendas)) {
                    Funcionarios oldIdFuncionarioOfVendasListNewVendas = vendasListNewVendas.getIdFuncionario();
                    vendasListNewVendas.setIdFuncionario(funcionarios);
                    vendasListNewVendas = em.merge(vendasListNewVendas);
                    if (oldIdFuncionarioOfVendasListNewVendas != null && !oldIdFuncionarioOfVendasListNewVendas.equals(funcionarios)) {
                        oldIdFuncionarioOfVendasListNewVendas.getVendasList().remove(vendasListNewVendas);
                        oldIdFuncionarioOfVendasListNewVendas = em.merge(oldIdFuncionarioOfVendasListNewVendas);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = funcionarios.getIdFuncionario();
                if (findFuncionarios(id) == null) {
                    throw new NonexistentEntityException("The funcionarios with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Funcionarios funcionarios;
            try {
                funcionarios = em.getReference(Funcionarios.class, id);
                funcionarios.getIdFuncionario();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The funcionarios with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            List<Vendas> vendasListOrphanCheck = funcionarios.getVendasList();
            for (Vendas vendasListOrphanCheckVendas : vendasListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Funcionarios (" + funcionarios + ") cannot be destroyed since the Vendas " + vendasListOrphanCheckVendas + " in its vendasList field has a non-nullable idFuncionario field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(funcionarios);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Funcionarios> findFuncionariosEntities() {
        return findFuncionariosEntities(true, -1, -1);
    }

    public List<Funcionarios> findFuncionariosEntities(int maxResults, int firstResult) {
        return findFuncionariosEntities(false, maxResults, firstResult);
    }

    private List<Funcionarios> findFuncionariosEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Funcionarios.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Funcionarios findFuncionarios(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Funcionarios.class, id);
        } finally {
            em.close();
        }
    }

    public int getFuncionariosCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Funcionarios> rt = cq.from(Funcionarios.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
