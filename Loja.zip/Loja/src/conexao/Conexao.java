/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexao;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author IFSP
 */
public class Conexao {
    
    /* 
        Esse método retorna o EntityManagerFactory, necessário para 
        instanciar as classes do tipo "JPAController" (dao)
    */
    public static EntityManagerFactory getEmf() {
        return Persistence.createEntityManagerFactory("LojaPU");
    } 
}
