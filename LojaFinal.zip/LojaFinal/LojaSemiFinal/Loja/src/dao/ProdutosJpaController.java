/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import beans.Itens;
import beans.Produtos;
import dao.exceptions.IllegalOrphanException;
import dao.exceptions.NonexistentEntityException;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author IFSP
 */
public class ProdutosJpaController implements Serializable {

    public ProdutosJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Produtos produtos) {
        if (produtos.getItensList() == null) {
            produtos.setItensList(new ArrayList<Itens>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            List<Itens> attachedItensList = new ArrayList<Itens>();
            for (Itens itensListItensToAttach : produtos.getItensList()) {
                itensListItensToAttach = em.getReference(itensListItensToAttach.getClass(), itensListItensToAttach.getIdItem());
                attachedItensList.add(itensListItensToAttach);
            }
            produtos.setItensList(attachedItensList);
            em.persist(produtos);
            for (Itens itensListItens : produtos.getItensList()) {
                Produtos oldIdProdutoOfItensListItens = itensListItens.getIdProduto();
                itensListItens.setIdProduto(produtos);
                itensListItens = em.merge(itensListItens);
                if (oldIdProdutoOfItensListItens != null) {
                    oldIdProdutoOfItensListItens.getItensList().remove(itensListItens);
                    oldIdProdutoOfItensListItens = em.merge(oldIdProdutoOfItensListItens);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Produtos produtos) throws IllegalOrphanException, NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Produtos persistentProdutos = em.find(Produtos.class, produtos.getIdProduto());
            List<Itens> itensListOld = persistentProdutos.getItensList();
            List<Itens> itensListNew = produtos.getItensList();
            List<String> illegalOrphanMessages = null;
            for (Itens itensListOldItens : itensListOld) {
                if (!itensListNew.contains(itensListOldItens)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Itens " + itensListOldItens + " since its idProduto field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            List<Itens> attachedItensListNew = new ArrayList<Itens>();
            for (Itens itensListNewItensToAttach : itensListNew) {
                itensListNewItensToAttach = em.getReference(itensListNewItensToAttach.getClass(), itensListNewItensToAttach.getIdItem());
                attachedItensListNew.add(itensListNewItensToAttach);
            }
            itensListNew = attachedItensListNew;
            produtos.setItensList(itensListNew);
            produtos = em.merge(produtos);
            for (Itens itensListNewItens : itensListNew) {
                if (!itensListOld.contains(itensListNewItens)) {
                    Produtos oldIdProdutoOfItensListNewItens = itensListNewItens.getIdProduto();
                    itensListNewItens.setIdProduto(produtos);
                    itensListNewItens = em.merge(itensListNewItens);
                    if (oldIdProdutoOfItensListNewItens != null && !oldIdProdutoOfItensListNewItens.equals(produtos)) {
                        oldIdProdutoOfItensListNewItens.getItensList().remove(itensListNewItens);
                        oldIdProdutoOfItensListNewItens = em.merge(oldIdProdutoOfItensListNewItens);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = produtos.getIdProduto();
                if (findProdutos(id) == null) {
                    throw new NonexistentEntityException("The produtos with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Produtos produtos;
            try {
                produtos = em.getReference(Produtos.class, id);
                produtos.getIdProduto();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The produtos with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            List<Itens> itensListOrphanCheck = produtos.getItensList();
            for (Itens itensListOrphanCheckItens : itensListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Produtos (" + produtos + ") cannot be destroyed since the Itens " + itensListOrphanCheckItens + " in its itensList field has a non-nullable idProduto field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(produtos);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Produtos> findProdutosEntities() {
        return findProdutosEntities(true, -1, -1);
    }

    public List<Produtos> findProdutosEntities(int maxResults, int firstResult) {
        return findProdutosEntities(false, maxResults, firstResult);
    }

    private List<Produtos> findProdutosEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Produtos.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Produtos findProdutos(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Produtos.class, id);
        } finally {
            em.close();
        }
    }

    public int getProdutosCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Produtos> rt = cq.from(Produtos.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

    public Produtos findProdutosPorNome(String nome) {
        EntityManager em = getEntityManager();
        try {
            List<Produtos> resultado = em.createQuery(
                    "SELECT p FROM Produtos p WHERE p.nome = :nome",
                    Produtos.class
            )
                    .setParameter("nome", nome)
                    .getResultList();
            
            if (resultado.isEmpty()) {
                return null;
            }
            return resultado.get(0);
        } finally {
            em.close();
        }
    }
    
}
