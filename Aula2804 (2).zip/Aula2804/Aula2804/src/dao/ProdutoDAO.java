/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import beans.Produto;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author IFSP
 */

public class ProdutoDAO {
    private Connection conn;
    public ProdutoDAO()
    {
        this.conn = Conexao.getConexao();
    }
    
    public void salvar(Produto produtos) throws Exception{
        String sql = "INSERT INTO produtos(nomeProduto, valor) VALUES (?, ?)";
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, produtos.getNomeProduto());
            stmt.setInt(2, produtos.getValor());
            stmt.execute();
        } catch (Exception e) {
            throw new Exception("ERRO AO SALVAR: " + e.getMessage());
        }
    }
    
    public Produto getProduto(int id){
        String sql = "SELECT * FROM produtos WHERE id = ?";
    }
}
