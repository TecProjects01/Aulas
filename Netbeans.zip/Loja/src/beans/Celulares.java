/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author rikel
 */
@Entity
@Table(name = "celulares")
@NamedQueries({
    @NamedQuery(name = "Celulares.findAll", query = "SELECT c FROM Celulares c"),
    @NamedQuery(name = "Celulares.findByIdCelular", query = "SELECT c FROM Celulares c WHERE c.idCelular = :idCelular"),
    @NamedQuery(name = "Celulares.findByMarca", query = "SELECT c FROM Celulares c WHERE c.marca = :marca"),
    @NamedQuery(name = "Celulares.findByModelo", query = "SELECT c FROM Celulares c WHERE c.modelo = :modelo"),
    @NamedQuery(name = "Celulares.findByPreco", query = "SELECT c FROM Celulares c WHERE c.preco = :preco"),
    @NamedQuery(name = "Celulares.findByDataVenda", query = "SELECT c FROM Celulares c WHERE c.dataVenda = :dataVenda")})
public class Celulares implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_celular")
    private Integer idCelular;
    @Basic(optional = false)
    @Column(name = "marca")
    private String marca;
    @Basic(optional = false)
    @Column(name = "modelo")
    private String modelo;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Basic(optional = false)
    @Column(name = "preco")
    private BigDecimal preco;
    @Column(name = "data_venda")
    @Temporal(TemporalType.DATE)
    private Date dataVenda;
    @JoinColumn(name = "id_cliente", referencedColumnName = "id_cliente")
    @ManyToOne(optional = false)
    private Cliente idCliente;
    @JoinColumn(name = "id_funcionario", referencedColumnName = "id_funcionario")
    @ManyToOne(optional = false)
    private Funcionarios idFuncionario;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idCelular")
    private Collection<Perifericos> perifericosCollection;

    public Celulares() {
    }

    public Celulares(Integer idCelular) {
        this.idCelular = idCelular;
    }

    public Celulares(Integer idCelular, String marca, String modelo, BigDecimal preco) {
        this.idCelular = idCelular;
        this.marca = marca;
        this.modelo = modelo;
        this.preco = preco;
    }

    public Integer getIdCelular() {
        return idCelular;
    }

    public void setIdCelular(Integer idCelular) {
        this.idCelular = idCelular;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public BigDecimal getPreco() {
        return preco;
    }

    public void setPreco(BigDecimal preco) {
        this.preco = preco;
    }

    public Date getDataVenda() {
        return dataVenda;
    }

    public void setDataVenda(Date dataVenda) {
        this.dataVenda = dataVenda;
    }

    public Cliente getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(Cliente idCliente) {
        this.idCliente = idCliente;
    }

    public Funcionarios getIdFuncionario() {
        return idFuncionario;
    }

    public void setIdFuncionario(Funcionarios idFuncionario) {
        this.idFuncionario = idFuncionario;
    }

    public Collection<Perifericos> getPerifericosCollection() {
        return perifericosCollection;
    }

    public void setPerifericosCollection(Collection<Perifericos> perifericosCollection) {
        this.perifericosCollection = perifericosCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idCelular != null ? idCelular.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Celulares)) {
            return false;
        }
        Celulares other = (Celulares) object;
        if ((this.idCelular == null && other.idCelular != null) || (this.idCelular != null && !this.idCelular.equals(other.idCelular))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "beans.Celulares[ idCelular=" + idCelular + " ]";
    }
    
}
