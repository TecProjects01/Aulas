/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author rikel
 */
@Entity
@Table(name = "perifericos")
@NamedQueries({
    @NamedQuery(name = "Perifericos.findAll", query = "SELECT p FROM Perifericos p"),
    @NamedQuery(name = "Perifericos.findByIdPeriferico", query = "SELECT p FROM Perifericos p WHERE p.idPeriferico = :idPeriferico"),
    @NamedQuery(name = "Perifericos.findByNome", query = "SELECT p FROM Perifericos p WHERE p.nome = :nome"),
    @NamedQuery(name = "Perifericos.findByTipo", query = "SELECT p FROM Perifericos p WHERE p.tipo = :tipo"),
    @NamedQuery(name = "Perifericos.findByPreco", query = "SELECT p FROM Perifericos p WHERE p.preco = :preco")})
public class Perifericos implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_periferico")
    private Integer idPeriferico;
    @Basic(optional = false)
    @Column(name = "nome")
    private String nome;
    @Basic(optional = false)
    @Column(name = "tipo")
    private String tipo;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Basic(optional = false)
    @Column(name = "preco")
    private BigDecimal preco;
    @JoinColumn(name = "id_celular", referencedColumnName = "id_celular")
    @ManyToOne(optional = false)
    private Celulares idCelular;

    public Perifericos() {
    }

    public Perifericos(Integer idPeriferico) {
        this.idPeriferico = idPeriferico;
    }

    public Perifericos(Integer idPeriferico, String nome, String tipo, BigDecimal preco) {
        this.idPeriferico = idPeriferico;
        this.nome = nome;
        this.tipo = tipo;
        this.preco = preco;
    }

    public Integer getIdPeriferico() {
        return idPeriferico;
    }

    public void setIdPeriferico(Integer idPeriferico) {
        this.idPeriferico = idPeriferico;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public BigDecimal getPreco() {
        return preco;
    }

    public void setPreco(BigDecimal preco) {
        this.preco = preco;
    }

    public Celulares getIdCelular() {
        return idCelular;
    }

    public void setIdCelular(Celulares idCelular) {
        this.idCelular = idCelular;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idPeriferico != null ? idPeriferico.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Perifericos)) {
            return false;
        }
        Perifericos other = (Perifericos) object;
        if ((this.idPeriferico == null && other.idPeriferico != null) || (this.idPeriferico != null && !this.idPeriferico.equals(other.idPeriferico))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "beans.Perifericos[ idPeriferico=" + idPeriferico + " ]";
    }
    
}
